English Homework 1 report

Overleaf: upload this ZIP as a new project; select Homework1_Report_EN.tex as the main document and XeLaTeX as compiler.
Local: run xelatex Homework1_Report_EN.tex twice, or tectonic Homework1_Report_EN.tex.
Keep the results/figures directory beside the main .tex file.
All required figures are included.
